# Recap -- experiment0
_Generato: 2026-08-18 13:33 UTC_

## 1. Stato di avanzamento
- 57/66 quest completate (22 task x 3 config: A/B/F)
- **9 quest ancora da fare:**
  - **A** (A -- Expert da solo): 3 mancanti
    - off_by_one__binary_search__known_example [KNOWN]
    - wrong_comparison_operator__run_length_encode__variant [VARIANT]
    - wrong_return_in_loop__dedupe_preserve_order__novel_a [NOVEL]
  - **B** (B -- Small da solo): 3 mancanti
    - off_by_one__binary_search__known_example [KNOWN]
    - wrong_comparison_operator__run_length_encode__variant [VARIANT]
    - wrong_return_in_loop__dedupe_preserve_order__novel_a [NOVEL]
  - **F** (F -- Small + Librarian): 3 mancanti
    - off_by_one__binary_search__known_example [KNOWN]
    - wrong_comparison_operator__run_length_encode__variant [VARIANT]
    - wrong_return_in_loop__dedupe_preserve_order__novel_a [NOVEL]
  (rilancia `tools\start.bat` per far avanzare -- riprende da solo dal checkpoint)

## 2. Confronto A / B / F
A = Expert da solo, B = Small da solo, F = Small + skill dalla Libreria.

| config | split | n | accuracy | costo tot | latenza media (ms) |
|---|---|---|---|---|---|
| A | KNOWN | 7 | 100.0% | $0.0000 | 16147 |
| A | NOVEL | 5 | 100.0% | $0.0000 | 17837 |
| A | VARIANT | 7 | 100.0% | $0.0000 | 16160 |
| B | KNOWN | 7 | 85.7% | $0.0000 | 728 |
| B | NOVEL | 5 | 100.0% | $0.0000 | 689 |
| B | VARIANT | 7 | 100.0% | $0.0000 | 719 |
| F | KNOWN | 7 | 100.0% | $0.0000 | 772 |
| F | NOVEL | 5 | 100.0% | $0.0000 | 679 |
| F | VARIANT | 7 | 85.7% | $0.0000 | 731 |

**Totali per config:**
- A -- Expert da solo: accuracy 100.0%, costo totale $0.0000, latenza media 16597ms, n=19
- B -- Small da solo: accuracy 94.7%, costo totale $0.0000, latenza media 715ms, n=19
- F -- Small + Librarian: accuracy 94.7%, costo totale $0.0000, latenza media 732ms, n=19
- B vs A (Small senza aiuto vs Expert): -5.3% accuracy
- F vs B (effetto della Libreria sul modello Small): +0.0% accuracy
- F vs A (quanto F si avvicina all'Expert): -5.3% accuracy

## 3. Token accounting
Token reali per config -- separato da costo_usd perche' quello e' $0 finche' GEMINI_INPUT_PER_MTOK/OUTPUT_PER_MTOK non sono impostati in .env. "reasoning" sono i token di pensiero di Gemini (fatturati, ma mai inclusi in "output").

| config | n | input | output | reasoning | totale | tok/task | tok/successo | accuracy |
|---|---|---|---|---|---|---|---|---|
| A | 19 | 2940 | 1303 | 22472 | 26715 | 1406 | 1406 | 100.0% |
| B | 19 | 2940 | 1329 | 0 | 4269 | 225 | 237 | 94.7% |
| F | 19 | 7192 | 1338 | 0 | 8530 | 449 | 474 | 94.7% |
- "tok/successo" = token totali / task risolti (non /n) -- un config con qualche fallimento sta comunque spendendo quei token senza ottenere un risultato utile, quindi e' un confronto piu' onesto di tok/task quando le accuracy non sono identiche.

- Overhead della Libreria (F vs B, stesso task): +224 token di input in media (min 0, max 327) -- il costo di *usare* uno skill gia' pronto.
- Costo dell'Optimizer in questa run (costo di *costruire* la conoscenza, non di usarla): 6 compressioni + 12 riverifiche = 7087 token totali (1181/skill in media). E' un costo una tantum per skill, non per uso -- si ammortizza sulle usi future, a differenza dell'overhead della Libreria sopra che si paga ad ogni retrieval.

## 4. Ammortamento delle skill (costruzione vs uso)
Per pattern di bug: costo una tantum per costruire/comprimere quella skill (Optimizer, qualunque tentativo, accettato o no) contro il risparmio medio per uso di F rispetto ad A sui task che quella skill copre. "breakeven" = dopo quanti usi il costo di costruzione si ripaga rispetto a chiamare sempre Expert. **Attenzione**: 2 task per pattern in questa run -- direzione indicativa, non un numero da citare come definitivo.

| pattern | costo costruzione | n task | A tok/task | F tok/task | risparmio/uso | breakeven |
|---|---|---|---|---|---|---|
| `floating_point_equality` | 1105 | 2 | 2709 | 478 | +2231 | 0.5 usi |
| `index_out_of_range_boundary` | 1339 | 2 | 1003 | 600 | +402 | 3.3 usi |
| `integer_division_truncation` | 1237 | 2 | 884 | 540 | +344 | 3.6 usi |
| `inverted_boolean_logic` | 1119 | 2 | 1988 | 513 | +1474 | 0.8 usi |
| `mutable_default_argument` | 1168 | 2 | 1510 | 508 | +1002 | 1.2 usi |
| `wrong_accumulator_init` | 1119 | 2 | 658 | 502 | +156 | 7.2 usi |

## 5. Quest fallite
- **B** [KNOWN] `floating_point_equality__average_matches_target__known_example`
- **F** [VARIANT] `floating_point_equality__temperature_reached__variant`

**Pattern di bug con fallimenti in piu' di un config:**
- `floating_point_equality`: B su floating_point_equality__average_matches_target__known_example, F su floating_point_equality__temperature_reached__variant -- **task diversi della stessa famiglia di bug** falliscono su config diversi. Da controllare quest per quest in `observer_table.csv` (colonna `retrieved_tokens`) se lo skill recuperato e' lo stesso e se l'ha aiutato o confuso.

## 6. Uso degli skill (Librarian)
| skill | usi | token medi | quest passate su quest usate |
|---|---|---|---|
| `book_floating_point_equality` | 2 | 327 | 1/2 |
| `book_index_out_of_range_boundary` | 2 | 296 | 2/2 |
| `book_integer_division_truncation` | 2 | 292 | 2/2 |
| `book_inverted_boolean_logic` | 2 | 314 | 2/2 |
| `book_mutable_default_argument` | 2 | 291 | 2/2 |
| `book_off_by_one` | 1 | 306 | 1/1 |
| `book_wrong_accumulator_init` | 2 | 309 | 2/2 |
| `book_wrong_comparison_operator` | 1 | 288 | 1/1 |

## 7. Optimizer (compressione skill)
- `book_mutable_default_argument`: ACCETTATA (compresso 2 passate vs originale 2 passate, stesso set di task riverificati)
- `book_index_out_of_range_boundary`: ACCETTATA (compresso 2 passate vs originale 2 passate, stesso set di task riverificati)
- `book_inverted_boolean_logic`: ACCETTATA (compresso 2 passate vs originale 2 passate, stesso set di task riverificati)
- `book_wrong_accumulator_init`: ACCETTATA (compresso 2 passate vs originale 2 passate, stesso set di task riverificati)
- `book_integer_division_truncation`: ACCETTATA (compresso 2 passate vs originale 2 passate, stesso set di task riverificati)
- `book_floating_point_equality`: ACCETTATA (compresso 1 passate vs originale 1 passate, stesso set di task riverificati)

## 8. Mappa delle sezioni
Vista condensata -- il dettaglio (crescita della libreria nel tempo, file su disco vs skill "attuali") e' in `knowledge_map.md` (`tools\knowledge_map.bat`).

| sezione | pattern | coverage | book | usi | costo costruzione |
|---|---|---|---|---|---|
| `boundary_conditions` | off_by_one, wrong_comparison_operator, index_out_of_range_boundary, wrong_return_in_loop | PARTIALLY_COVERED | 3 | 4 | 1339 |
| `numerical_computing` | floating_point_equality, integer_division_truncation | COVERED | 2 | 4 | 2342 |
| `loop_state` | wrong_accumulator_init | COVERED | 1 | 2 | 1119 |
| `language_semantics` | mutable_default_argument, variable_shadowing | PARTIALLY_COVERED | 1 | 2 | 1168 |
| `boolean_logic` | inverted_boolean_logic | COVERED | 1 | 2 | 1119 |
| `data_ordering` | incorrect_sort_key_or_order | EMPTY | 0 | 0 | 0 |

## Nota metodologica
Ogni cella (task, config) ha una sola run. Un singolo fallimento non basta per dire se e' un problema sistematico dello skill o una variazione casuale del modello -- serve ripetere lo stesso task piu' volte per distinguerli.
Tutti i costi risultano $0.00: probabile prezzo non configurato per il provider in uso (vedi `GEMINI_INPUT_PER_MTOK`/`GEMINI_OUTPUT_PER_MTOK` in `.env`), non un run gratuito per davvero -- non affidarti a questo numero per ora.
