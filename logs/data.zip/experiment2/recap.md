# Recap -- experiment2
_Generato: 2026-08-18 14:43 UTC_

## 1. Stato di avanzamento
- 40/104 quest completate (26 task x 4 config: A/B/F)
- **64 quest ancora da fare:**
  - **A** (A -- Expert da solo): 16 mancanti
    - floating_point_equality__temperature_reached__variant [VARIANT]
    - incorrect_sort_key_or_order__merge_intervals__novel_a [NOVEL]
    - off_by_one__rolling_average__variant [VARIANT]
    - index_out_of_range_boundary__run_length_encode__known_example [KNOWN]
    - key_error_missing_dict_check__sum_scores_by_player__variant [VARIANT]
    - wrong_accumulator_init__reverse_words__variant [VARIANT]
    - wrong_comparison_operator__merge_intervals__known_example [KNOWN]
    - variable_shadowing__reverse_words__novel_b [NOVEL]
    - wrong_string_case_comparison__find_matching_tag__known_example [KNOWN]
    - mutable_default_argument__dedupe_preserve_order__known_example [KNOWN]
    - wrong_return_in_loop__flatten_list__novel_b [NOVEL]
    - integer_division_truncation__binary_search__variant [VARIANT]
    - inverted_boolean_logic__is_leap_year__known_example [KNOWN]
    - off_by_one__binary_search__known_example [KNOWN]
    - wrong_comparison_operator__run_length_encode__variant [VARIANT]
    - wrong_return_in_loop__dedupe_preserve_order__novel_a [NOVEL]
  - **B** (B -- Small da solo): 16 mancanti
    - floating_point_equality__temperature_reached__variant [VARIANT]
    - incorrect_sort_key_or_order__merge_intervals__novel_a [NOVEL]
    - off_by_one__rolling_average__variant [VARIANT]
    - index_out_of_range_boundary__run_length_encode__known_example [KNOWN]
    - key_error_missing_dict_check__sum_scores_by_player__variant [VARIANT]
    - wrong_accumulator_init__reverse_words__variant [VARIANT]
    - wrong_comparison_operator__merge_intervals__known_example [KNOWN]
    - variable_shadowing__reverse_words__novel_b [NOVEL]
    - wrong_string_case_comparison__find_matching_tag__known_example [KNOWN]
    - mutable_default_argument__dedupe_preserve_order__known_example [KNOWN]
    - wrong_return_in_loop__flatten_list__novel_b [NOVEL]
    - integer_division_truncation__binary_search__variant [VARIANT]
    - inverted_boolean_logic__is_leap_year__known_example [KNOWN]
    - off_by_one__binary_search__known_example [KNOWN]
    - wrong_comparison_operator__run_length_encode__variant [VARIANT]
    - wrong_return_in_loop__dedupe_preserve_order__novel_a [NOVEL]
  - **F** (F -- Small + Librarian): 16 mancanti
    - floating_point_equality__temperature_reached__variant [VARIANT]
    - incorrect_sort_key_or_order__merge_intervals__novel_a [NOVEL]
    - off_by_one__rolling_average__variant [VARIANT]
    - index_out_of_range_boundary__run_length_encode__known_example [KNOWN]
    - key_error_missing_dict_check__sum_scores_by_player__variant [VARIANT]
    - wrong_accumulator_init__reverse_words__variant [VARIANT]
    - wrong_comparison_operator__merge_intervals__known_example [KNOWN]
    - variable_shadowing__reverse_words__novel_b [NOVEL]
    - wrong_string_case_comparison__find_matching_tag__known_example [KNOWN]
    - mutable_default_argument__dedupe_preserve_order__known_example [KNOWN]
    - wrong_return_in_loop__flatten_list__novel_b [NOVEL]
    - integer_division_truncation__binary_search__variant [VARIANT]
    - inverted_boolean_logic__is_leap_year__known_example [KNOWN]
    - off_by_one__binary_search__known_example [KNOWN]
    - wrong_comparison_operator__run_length_encode__variant [VARIANT]
    - wrong_return_in_loop__dedupe_preserve_order__novel_a [NOVEL]
  - **C** (C -- Small + Cheater (soluzione pregressa)): 16 mancanti
    - floating_point_equality__temperature_reached__variant [VARIANT]
    - incorrect_sort_key_or_order__merge_intervals__novel_a [NOVEL]
    - off_by_one__rolling_average__variant [VARIANT]
    - index_out_of_range_boundary__run_length_encode__known_example [KNOWN]
    - key_error_missing_dict_check__sum_scores_by_player__variant [VARIANT]
    - wrong_accumulator_init__reverse_words__variant [VARIANT]
    - wrong_comparison_operator__merge_intervals__known_example [KNOWN]
    - variable_shadowing__reverse_words__novel_b [NOVEL]
    - wrong_string_case_comparison__find_matching_tag__known_example [KNOWN]
    - mutable_default_argument__dedupe_preserve_order__known_example [KNOWN]
    - wrong_return_in_loop__flatten_list__novel_b [NOVEL]
    - integer_division_truncation__binary_search__variant [VARIANT]
    - inverted_boolean_logic__is_leap_year__known_example [KNOWN]
    - off_by_one__binary_search__known_example [KNOWN]
    - wrong_comparison_operator__run_length_encode__variant [VARIANT]
    - wrong_return_in_loop__dedupe_preserve_order__novel_a [NOVEL]
  (rilancia `tools\start.bat` per far avanzare -- riprende da solo dal checkpoint)

## 2. Confronto A / B / F
A = Expert da solo, B = Small da solo, F = Small + skill dalla Libreria.

| config | split | n | accuracy | costo tot | latenza media (ms) |
|---|---|---|---|---|---|
| A | KNOWN | 4 | 75.0% | $0.0000 | 16951 |
| A | NOVEL | 2 | 100.0% | $0.0000 | 19868 |
| A | VARIANT | 4 | 100.0% | $0.0000 | 27902 |
| B | KNOWN | 4 | 75.0% | $0.0000 | 1595 |
| B | NOVEL | 2 | 100.0% | $0.0000 | 1922 |
| B | VARIANT | 4 | 75.0% | $0.0000 | 1277 |
| C | KNOWN | 4 | 100.0% | $0.0000 | 1229 |
| C | NOVEL | 2 | 100.0% | $0.0000 | 3219 |
| C | VARIANT | 4 | 100.0% | $0.0000 | 995 |
| F | KNOWN | 4 | 100.0% | $0.0000 | 5651 |
| F | NOVEL | 2 | 100.0% | $0.0000 | 2927 |
| F | VARIANT | 4 | 100.0% | $0.0000 | 2509 |

**Totali per config:**
- A -- Expert da solo: accuracy 90.0%, costo totale $0.0000, latenza media 21915ms, n=10
- B -- Small da solo: accuracy 80.0%, costo totale $0.0000, latenza media 1533ms, n=10
- F -- Small + Librarian: accuracy 100.0%, costo totale $0.0000, latenza media 3849ms, n=10
- C -- Small + Cheater (soluzione pregressa): accuracy 100.0%, costo totale $0.0000, latenza media 1534ms, n=10
- B vs A (Small senza aiuto vs Expert): -10.0% accuracy
- F vs B (effetto della Libreria sul modello Small): +20.0% accuracy
- F vs A (quanto F si avvicina all'Expert): +10.0% accuracy
- C vs B (l'accesso a una soluzione pregressa aiuta rispetto a niente?): +20.0% accuracy
- C vs F (soluzione specifica vs skill generalizzata -- la domanda centrale del Cheater Agent): +0.0% accuracy

## 3. Retrieval vs Architecture (coverage NONE/PARTIAL/FULL)
Separa "il meccanismo di retrieval esiste" da "il retrieval ha trovato qualcosa di pertinente" -- per F (Skill Library) e C (Solution Bank), ogni quest ha gia' un `coverage` salvato (NONE=niente trovato, PARTIAL=match parziale/imperfetto, FULL=match esatto/completo). Se **F-NONE ~= B** e **F-FULL > B**, e' il retrieval a spostare l'accuracy, non la sola presenza del meccanismo.

**F -- Small + Librarian:**
| coverage | n | accuracy |
|---|---|---|
| NONE | 2 | 100.0% |
| FULL | 8 | 100.0% |
- Δ Retrieval (FULL − NONE, dentro F stesso): +0.0%
- Δ Architecture (F-FULL − B): +20.0%

**C -- Small + Cheater (soluzione pregressa):**
| coverage | n | accuracy |
|---|---|---|
| NONE | 2 | 100.0% |
| PARTIAL | 4 | 100.0% |
| FULL | 4 | 100.0% |
- Δ Retrieval (FULL − NONE, dentro C stesso): +0.0%
- Δ Architecture (C-FULL − B): +20.0%

Il dettaglio per split (KNOWN/VARIANT/NOVEL) di ogni config e' gia' nella tabella della sezione 2 sopra -- known_example ~ FULL/EXACT, variant ~ PARTIAL/SEEN per definizione di come route()/lookup() funzionano, quindi le due viste si leggono insieme.

## 4. Token accounting
Token reali per config -- separato da costo_usd perche' quello e' $0 finche' GEMINI_INPUT_PER_MTOK/OUTPUT_PER_MTOK non sono impostati in .env. "reasoning" sono i token di pensiero di Gemini (fatturati, ma mai inclusi in "output").

| config | n | input | output | reasoning | totale | tok/task | tok/successo | accuracy |
|---|---|---|---|---|---|---|---|---|
| A | 10 | 1425 | 612 | 4125 | 6162 | 616 | 685 | 90.0% |
| B | 10 | 1425 | 617 | 0 | 2042 | 204 | 255 | 80.0% |
| F | 10 | 2869 | 636 | 0 | 3505 | 350 | 350 | 100.0% |
| C | 10 | 2204 | 631 | 0 | 2835 | 284 | 284 | 100.0% |
- "tok/successo" = token totali / task risolti (non /n) -- un config con qualche fallimento sta comunque spendendo quei token senza ottenere un risultato utile, quindi e' un confronto piu' onesto di tok/task quando le accuracy non sono identiche.

- Overhead della Libreria (F vs B, stesso task): +144 token di input in media (min 0, max 366) -- il costo di *usare* uno skill gia' pronto.

## 5. Ammortamento delle skill (costruzione vs uso)
Per pattern di bug: costo una tantum per costruire/comprimere quella skill (Optimizer, qualunque tentativo, accettato o no) contro il risparmio medio per uso di F rispetto ad A sui task che quella skill copre. "breakeven" = dopo quanti usi il costo di costruzione si ripaga rispetto a chiamare sempre Expert. **Attenzione**: 2 task per pattern in questa run -- direzione indicativa, non un numero da citare come definitivo.

- Nessun dato (serve almeno un retrieval F + una compressione per lo stesso pattern).

## 6. Quest fallite
- **A** [KNOWN] `floating_point_equality__average_matches_target__known_example`
- **B** [KNOWN] `floating_point_equality__average_matches_target__known_example`
- **B** [VARIANT] `wrong_string_case_comparison__is_valid_username__variant`

**Pattern di bug con fallimenti in piu' di un config:**
- `floating_point_equality`: A su floating_point_equality__average_matches_target__known_example, B su floating_point_equality__average_matches_target__known_example -- stesso task, probabilmente e' il task in se' ad essere difficile per tutti (non e' una domanda sulla Libreria).

## 7. Uso degli skill (Librarian)
| skill | usi | token medi | quest passate su quest usate |
|---|---|---|---|
| `book_floating_point_equality_v4` | 1 | 204 | 1/1 |
| `book_index_out_of_range_boundary_v2_v3` | 1 | 98 | 1/1 |
| `book_integer_division_truncation_v2_v3` | 1 | 104 | 1/1 |
| `book_inverted_boolean_logic_v2_v3` | 1 | 99 | 1/1 |
| `book_key_error_missing_dict_check` | 1 | 360 | 1/1 |
| `book_mutable_default_argument_v2_v3` | 1 | 106 | 1/1 |
| `book_wrong_accumulator_init_v2_v3` | 1 | 107 | 1/1 |
| `book_wrong_string_case_comparison` | 1 | 366 | 1/1 |
| `solution_average_matches_target` | 1 | 74 | 1/1 |
| `solution_count_vowels` | 1 | 90 | 1/1 |
| `solution_count_word_frequency` | 1 | 84 | 1/1 |
| `solution_dedupe_preserve_order` | 1 | 97 | 1/1 |
| `solution_find_matching_tag` | 1 | 88 | 1/1 |
| `solution_is_leap_year` | 1 | 93 | 1/1 |
| `solution_rolling_average` | 1 | 98 | 1/1 |
| `solution_run_length_encode` | 1 | 155 | 1/1 |

## 8. Optimizer (compressione skill)
- Non ancora lanciato per questo experiment_id (`tools\optimizer.bat`).

## 9. Mappa delle sezioni
Vista condensata -- il dettaglio (crescita della libreria nel tempo, file su disco vs skill "attuali") e' in `knowledge_map.md` (`tools\knowledge_map.bat`).

| sezione | pattern | coverage | book | usi | costo costruzione |
|---|---|---|---|---|---|
| `boundary_conditions` | off_by_one, wrong_comparison_operator, index_out_of_range_boundary, wrong_return_in_loop | PARTIALLY_COVERED | 3 | 1 | 0 |
| `numerical_computing` | floating_point_equality, integer_division_truncation | COVERED | 2 | 2 | 0 |
| `loop_state` | wrong_accumulator_init | COVERED | 1 | 1 | 0 |
| `language_semantics` | mutable_default_argument, variable_shadowing | PARTIALLY_COVERED | 1 | 1 | 0 |
| `boolean_logic` | inverted_boolean_logic | COVERED | 1 | 1 | 0 |
| `data_ordering` | incorrect_sort_key_or_order | EMPTY | 0 | 0 | 0 |
| `data_structures` | key_error_missing_dict_check | COVERED | 1 | 1 | 0 |
| `string_processing` | wrong_string_case_comparison | COVERED | 1 | 1 | 0 |

## Nota metodologica
Ogni cella (task, config) ha una sola run. Un singolo fallimento non basta per dire se e' un problema sistematico dello skill o una variazione casuale del modello -- serve ripetere lo stesso task piu' volte per distinguerli.
Tutti i costi risultano $0.00: probabile prezzo non configurato per il provider in uso (vedi `GEMINI_INPUT_PER_MTOK`/`GEMINI_OUTPUT_PER_MTOK` in `.env`), non un run gratuito per davvero -- non affidarti a questo numero per ora.
